class UsersController < ApplicationController
  before_action :require_logged_out
  
  def new
  end

  def create
  end
end